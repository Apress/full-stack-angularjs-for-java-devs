insert into users (username, password, enabled, role) values ('user', 'password', true, 'USER');
insert into users (username, password, enabled, role) values ('admin', 'password', true, 'ADMIN');
insert into users (username, password, enabled, role) values ('ravi', 'password', true, 'USER');