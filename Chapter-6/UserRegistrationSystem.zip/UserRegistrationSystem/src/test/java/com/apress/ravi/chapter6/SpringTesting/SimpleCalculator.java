package com.apress.ravi.chapter6.SpringTesting;

public class SimpleCalculator {

	public long addOperation(int x, int y) {
		return x + y;
	}
}
